"""
Script de seed — roda UMA vez para preparar o banco:
- Cria o admin padrão (se ainda não existir)
- Cria os índices necessários

Como rodar (depois de configurar o MONGODB_URI no .env):
    python -m api.seed
"""
import asyncio
from .database import get_db, admins_col, events_col, batches_col, registrations_col, tickets_col, waitlist_col
from .auth import hash_password

DEFAULT_ADMIN_EMAIL = "admin@bornchurch.com.br"
DEFAULT_ADMIN_PASSWORD = "LEqIEUQCoAzmZv"  # troque assim que fizer o primeiro login!


async def seed():
    existing = await admins_col().find_one({"email": DEFAULT_ADMIN_EMAIL})
    if existing:
        print(f"Admin '{DEFAULT_ADMIN_EMAIL}' já existe — nada foi alterado.")
    else:
        await admins_col().insert_one({
            "email": DEFAULT_ADMIN_EMAIL,
            "password_hash": hash_password(DEFAULT_ADMIN_PASSWORD),
            "name": "Administrador",
        })
        print("Admin padrão criado:")
        print(f"  E-mail: {DEFAULT_ADMIN_EMAIL}")
        print(f"  Senha:  {DEFAULT_ADMIN_PASSWORD}")
        print("  >>> troque essa senha assim que possível <<<")

    # Índices
    await events_col().create_index("status")
    await events_col().create_index("start_date")
    await batches_col().create_index("event_id")
    await registrations_col().create_index("event_id")
    await registrations_col().create_index("buyer_email")
    await registrations_col().create_index("asaas_payment_id")
    await tickets_col().create_index("qr_token", unique=True)
    await tickets_col().create_index("event_id")
    await waitlist_col().create_index("event_id")
    await waitlist_col().create_index("status")

    print("Índices garantidos. Banco pronto para uso.")


if __name__ == "__main__":
    asyncio.run(seed())
