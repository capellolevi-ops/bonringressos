"""
Cliente para a API do Asaas (gateway de pagamento).
Documentação: https://docs.asaas.com
"""
import httpx
from .config import settings


def _headers() -> dict:
    return {
        "access_token": settings.ASAAS_API_KEY,
        "Content-Type": "application/json",
        "User-Agent": "born-church-tickets",
    }


async def find_or_create_customer(name: str, email: str, phone: str, document: str | None) -> str:
    """Procura um cliente pelo e-mail; cria se não existir. Retorna o customer id do Asaas."""
    async with httpx.AsyncClient(base_url=settings.asaas_base_url, headers=_headers(), timeout=20) as client:
        resp = await client.get("/customers", params={"email": email})
        resp.raise_for_status()
        data = resp.json()
        if data.get("data"):
            return data["data"][0]["id"]

        payload = {"name": name, "email": email, "mobilePhone": phone}
        if document:
            payload["cpfCnpj"] = document
        resp = await client.post("/customers", json=payload)
        resp.raise_for_status()
        return resp.json()["id"]


async def create_payment(customer_id: str, value: float, description: str,
                          billing_type: str, due_date: str, external_reference: str) -> dict:
    """Cria uma cobrança no Asaas. billing_type: 'PIX' ou 'CREDIT_CARD'."""
    payload = {
        "customer": customer_id,
        "billingType": billing_type,
        "value": value,
        "dueDate": due_date,
        "description": description,
        "externalReference": external_reference,
    }
    async with httpx.AsyncClient(base_url=settings.asaas_base_url, headers=_headers(), timeout=20) as client:
        resp = await client.post("/payments", json=payload)
        resp.raise_for_status()
        return resp.json()


async def get_pix_qr_code(payment_id: str) -> dict:
    """Retorna {encodedImage, payload, expirationDate} do PIX dinâmico de uma cobrança."""
    async with httpx.AsyncClient(base_url=settings.asaas_base_url, headers=_headers(), timeout=20) as client:
        resp = await client.get(f"/payments/{payment_id}/pixQrCode")
        resp.raise_for_status()
        return resp.json()


async def get_payment(payment_id: str) -> dict:
    async with httpx.AsyncClient(base_url=settings.asaas_base_url, headers=_headers(), timeout=20) as client:
        resp = await client.get(f"/payments/{payment_id}")
        resp.raise_for_status()
        return resp.json()
