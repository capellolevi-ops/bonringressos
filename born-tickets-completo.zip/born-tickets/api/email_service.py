"""
Envio de e-mail transacional via Gmail (SMTP) — de graça, sem precisar de domínio próprio.

Como configurar (grátis):
1. Ative a verificação em duas etapas na conta do Gmail que vai enviar os e-mails
   (myaccount.google.com/security)
2. Crie uma "senha de app" em myaccount.google.com/apppasswords
3. Coloque o e-mail em GMAIL_ADDRESS e a senha de app (16 caracteres) em GMAIL_APP_PASSWORD
"""
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import aiosmtplib

from .config import settings

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587


async def send_email(to: str, subject: str, html: str) -> bool:
    """Retorna True se enviou, False se falhou. Nunca levanta exceção — e-mail não pode derrubar o pagamento."""
    if not settings.GMAIL_ADDRESS or not settings.GMAIL_APP_PASSWORD:
        print(f"[email] GMAIL_ADDRESS/GMAIL_APP_PASSWORD não configurados — e-mail para {to} não foi enviado.")
        return False

    message = MIMEMultipart("alternative")
    message["Subject"] = subject
    message["From"] = f"{settings.EMAIL_FROM_NAME} <{settings.GMAIL_ADDRESS}>"
    message["To"] = to
    message.attach(MIMEText(html, "html"))

    try:
        await aiosmtplib.send(
            message,
            hostname=SMTP_HOST,
            port=SMTP_PORT,
            start_tls=True,
            username=settings.GMAIL_ADDRESS,
            password=settings.GMAIL_APP_PASSWORD,
        )
        return True
    except Exception as e:
        print(f"[email] Falha ao enviar para {to}: {e}")
        return False
