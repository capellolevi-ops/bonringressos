"""
Configuração central do sistema.
Todos os valores sensíveis vêm de variáveis de ambiente — nunca hardcode aqui.
"""
import os


class Settings:
    # Banco de dados
    MONGODB_URI: str = os.environ.get("MONGODB_URI", "")
    MONGODB_DB_NAME: str = os.environ.get("MONGODB_DB_NAME", "born_tickets")

    # Autenticação do admin
    JWT_SECRET: str = os.environ.get("JWT_SECRET", "troque-este-segredo-em-producao")
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_HOURS: int = 12

    # Token de uso único para /api/setup (criar o admin sem precisar rodar nada localmente)
    SETUP_TOKEN: str = os.environ.get("SETUP_TOKEN", "")

    # Asaas (gateway de pagamento)
    ASAAS_API_KEY: str = os.environ.get("ASAAS_API_KEY", "")
    ASAAS_ENV: str = os.environ.get("ASAAS_ENV", "production")  # "production" ou "sandbox"
    ASAAS_WEBHOOK_TOKEN: str = os.environ.get("ASAAS_WEBHOOK_TOKEN", "")
    PIX_KEY: str = os.environ.get("PIX_KEY", "48.891.677/0001-93")

    # E-mail (envio de ingressos e avisos de lista de espera) — via Gmail, de graça
    GMAIL_ADDRESS: str = os.environ.get("GMAIL_ADDRESS", "")
    GMAIL_APP_PASSWORD: str = os.environ.get("GMAIL_APP_PASSWORD", "")
    EMAIL_FROM_NAME: str = os.environ.get("EMAIL_FROM_NAME", "Born Church")

    # URL pública do site (usada em links de e-mail e no webhook)
    PUBLIC_BASE_URL: str = os.environ.get("PUBLIC_BASE_URL", "http://localhost:5173")

    @property
    def asaas_base_url(self) -> str:
        if self.ASAAS_ENV == "sandbox":
            return "https://api-sandbox.asaas.com/v3"
        return "https://api.asaas.com/v3"


settings = Settings()
