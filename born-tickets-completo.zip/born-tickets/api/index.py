"""
Ponto de entrada da API (Born Church — Ingressos).
Na Vercel, este arquivo é detectado automaticamente como a função Python.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import auth_routes, events, batches, registrations, webhooks, checkin, waitlist, setup

app = FastAPI(title="Born Church — Ingressos API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # o front e a API vivem no mesmo domínio na Vercel
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_routes.router)
app.include_router(events.router)
app.include_router(batches.router)
app.include_router(registrations.router)
app.include_router(webhooks.router)
app.include_router(checkin.router)
app.include_router(waitlist.router)
app.include_router(setup.router)


@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "born-church-tickets-api"}
