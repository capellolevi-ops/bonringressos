"""
Geração dos ingressos digitais (um por participante) com QR Code, e envio por e-mail.
Chamado automaticamente pelo webhook quando um pagamento é confirmado.
"""
import base64
import io
import secrets

import qrcode

from .database import tickets_col, events_col
from .email_service import send_email
from .config import settings


def _new_qr_token() -> str:
    return secrets.token_urlsafe(24)


def _qr_image_base64(data: str) -> str:
    img = qrcode.make(data, box_size=8, border=2)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


async def generate_tickets_for_registration(registration: dict) -> list[dict]:
    """Cria um Ticket por participante da inscrição. Idempotente: não duplica se já existirem."""
    existing = await tickets_col().find({"registration_id": str(registration["_id"])}).to_list(length=100)
    if existing:
        return existing

    tickets = []
    for attendee in registration["attendees"]:
        token = _new_qr_token()
        doc = {
            "registration_id": str(registration["_id"]),
            "event_id": registration["event_id"],
            "attendee_name": attendee["name"],
            "attendee_email": attendee.get("email") or registration["buyer_email"],
            "qr_token": token,
            "checked_in": False,
            "checked_in_at": None,
        }
        result = await tickets_col().insert_one(doc)
        doc["_id"] = result.inserted_id
        tickets.append(doc)
    return tickets


def _ticket_email_html(event_title: str, event_date: str, event_location: str,
                        buyer_name: str, tickets_html_blocks: str) -> str:
    return f"""
    <div style="font-family:Poppins,Arial,sans-serif;background:#09090b;padding:32px;color:#f6f3ec;">
      <div style="max-width:520px;margin:0 auto;">
        <p style="letter-spacing:.08em;color:#cda45e;font-size:13px;margin:0 0 4px;">BORN CHURCH</p>
        <h1 style="font-family:Georgia,serif;font-size:26px;margin:0 0 20px;color:#f6f3ec;">Seu ingresso chegou 🎟️</h1>
        <p style="color:#cecac1;line-height:1.6;">Olá, {buyer_name}! Seu pagamento para <strong>{event_title}</strong> foi confirmado.</p>
        <p style="color:#cecac1;line-height:1.6;margin-bottom:24px;">📅 {event_date} · 📍 {event_location}</p>
        {tickets_html_blocks}
        <p style="color:#8a8578;font-size:13px;margin-top:28px;">Apresente o QR Code na entrada do evento. Cada ingresso é individual.</p>
      </div>
    </div>
    """


def _one_ticket_block(attendee_name: str, qr_base64: str) -> str:
    return f"""
    <div style="background:#131316;border:1px solid #2a2a2e;border-radius:16px;padding:20px;margin-bottom:16px;text-align:center;">
      <p style="color:#f6f3ec;font-weight:600;margin:0 0 12px;">{attendee_name}</p>
      <img src="data:image/png;base64,{qr_base64}" alt="QR Code do ingresso" style="width:180px;height:180px;" />
    </div>
    """


async def generate_and_send_tickets(registration: dict):
    """Ponto de entrada chamado pelo webhook após confirmação de pagamento."""
    tickets = await generate_tickets_for_registration(registration)

    from bson import ObjectId
    event = await events_col().find_one({"_id": ObjectId(registration["event_id"])})

    event_title = event["title"] if event else "Evento"
    event_date = event["start_date"].strftime("%d/%m/%Y às %H:%M") if event else ""
    event_location = event["location"] if event else ""

    blocks = ""
    for t in tickets:
        qr_b64 = _qr_image_base64(t["qr_token"])
        blocks += _one_ticket_block(t["attendee_name"], qr_b64)

    html = _ticket_email_html(event_title, event_date, event_location, registration["buyer_name"], blocks)
    await send_email(
        to=registration["buyer_email"],
        subject=f"Seu ingresso — {event_title}",
        html=html,
    )
    return tickets
