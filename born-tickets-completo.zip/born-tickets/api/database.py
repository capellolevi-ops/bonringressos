"""
Conexão com o MongoDB (assíncrona, via Motor).
"""
from motor.motor_asyncio import AsyncIOMotorClient
from .config import settings

_client: AsyncIOMotorClient | None = None


def get_client() -> AsyncIOMotorClient:
    global _client
    if _client is None:
        _client = AsyncIOMotorClient(settings.MONGODB_URI)
    return _client


def get_db():
    return get_client()[settings.MONGODB_DB_NAME]


# Atalhos para cada coleção
def events_col():
    return get_db()["events"]


def batches_col():
    return get_db()["ticket_batches"]


def registrations_col():
    return get_db()["registrations"]


def tickets_col():
    return get_db()["tickets"]


def waitlist_col():
    return get_db()["waitlist"]


def admins_col():
    return get_db()["admin_users"]
