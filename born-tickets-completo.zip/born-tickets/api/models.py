"""
Modelos de dados (Pydantic) usados nas requisições e respostas da API.
"""
from datetime import datetime
from enum import Enum
from typing import Optional
from pydantic import BaseModel, EmailStr, Field


def serialize_doc(doc: dict) -> dict:
    """Converte um documento do Mongo (com _id ObjectId) em dict JSON-seguro."""
    if doc is None:
        return None
    doc = dict(doc)
    if "_id" in doc:
        doc["id"] = str(doc.pop("_id"))
    return doc


# ---------- Enums ----------

class EventStatus(str, Enum):
    draft = "draft"
    published = "published"
    closed = "closed"
    cancelled = "cancelled"


class BatchStatus(str, Enum):
    active = "active"
    soldout = "soldout"
    closed = "closed"


class PaymentStatus(str, Enum):
    pending = "pending"
    paid = "paid"
    expired = "expired"
    cancelled = "cancelled"
    refunded = "refunded"


class PaymentMethod(str, Enum):
    pix = "pix"
    card = "card"


class WaitlistStatus(str, Enum):
    waiting = "waiting"
    notified = "notified"
    converted = "converted"
    expired = "expired"


# ---------- Admin ----------

class AdminLogin(BaseModel):
    email: EmailStr
    password: str


class AdminOut(BaseModel):
    id: str
    email: EmailStr
    name: str


# ---------- Eventos ----------

class EventCreate(BaseModel):
    title: str
    description: str = ""
    start_date: datetime
    end_date: Optional[datetime] = None
    location: str
    image_url: Optional[str] = None
    status: EventStatus = EventStatus.draft


class EventUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    location: Optional[str] = None
    image_url: Optional[str] = None
    status: Optional[EventStatus] = None


class EventOut(BaseModel):
    id: str
    title: str
    description: str
    start_date: datetime
    end_date: Optional[datetime]
    location: str
    image_url: Optional[str]
    status: EventStatus
    created_at: datetime
    updated_at: datetime


# ---------- Lotes de ingresso ----------

class BatchCreate(BaseModel):
    event_id: str
    name: str
    price: float = Field(ge=0)
    quantity_total: int = Field(gt=0)
    sale_start: Optional[datetime] = None
    sale_end: Optional[datetime] = None
    max_per_purchase: int = Field(default=10, gt=0)


class BatchUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    quantity_total: Optional[int] = None
    sale_start: Optional[datetime] = None
    sale_end: Optional[datetime] = None
    max_per_purchase: Optional[int] = None
    status: Optional[BatchStatus] = None


class BatchOut(BaseModel):
    id: str
    event_id: str
    name: str
    price: float
    quantity_total: int
    quantity_sold: int
    quantity_available: int
    sale_start: Optional[datetime]
    sale_end: Optional[datetime]
    max_per_purchase: int
    status: BatchStatus


# ---------- Inscrições ----------

class Attendee(BaseModel):
    name: str
    document: Optional[str] = None
    email: Optional[EmailStr] = None


class RegistrationCreate(BaseModel):
    event_id: str
    batch_id: str
    buyer_name: str
    buyer_email: EmailStr
    buyer_phone: str
    buyer_document: Optional[str] = None
    quantity: int = Field(gt=0)
    attendees: list[Attendee] = []
    payment_method: PaymentMethod


class RegistrationOut(BaseModel):
    id: str
    event_id: str
    batch_id: str
    buyer_name: str
    buyer_email: EmailStr
    buyer_phone: str
    quantity: int
    attendees: list[Attendee]
    total_amount: float
    payment_status: PaymentStatus
    payment_method: PaymentMethod
    asaas_payment_id: Optional[str] = None
    pix_qr_code: Optional[str] = None
    pix_copy_paste: Optional[str] = None
    card_checkout_url: Optional[str] = None
    created_at: datetime


# ---------- Lista de espera ----------

class WaitlistCreate(BaseModel):
    event_id: str
    batch_id: Optional[str] = None
    name: str
    email: EmailStr
    phone: str
    quantity_wanted: int = Field(default=1, gt=0)


class WaitlistOut(BaseModel):
    id: str
    event_id: str
    batch_id: Optional[str]
    name: str
    email: EmailStr
    phone: str
    quantity_wanted: int
    status: WaitlistStatus
    created_at: datetime


# ---------- Ingressos / check-in ----------

class TicketOut(BaseModel):
    id: str
    registration_id: str
    event_id: str
    attendee_name: str
    qr_token: str
    checked_in: bool
    checked_in_at: Optional[datetime] = None


class CheckInRequest(BaseModel):
    qr_token: str
