from fastapi import APIRouter, Request, HTTPException, Header

from ..config import settings
from ..database import registrations_col, batches_col
from ..models import PaymentStatus
from ..ticket_service import generate_and_send_tickets
from .events import _oid
from .waitlist import notify_waitlist_for_batch

router = APIRouter(tags=["webhook"])

# Eventos que confirmam o pagamento
CONFIRMED_EVENTS = {"PAYMENT_CONFIRMED", "PAYMENT_RECEIVED"}
# Eventos que liberam a vaga de volta (o pagamento não vai acontecer)
RELEASE_EVENTS = {"PAYMENT_OVERDUE", "PAYMENT_DELETED", "PAYMENT_REFUNDED", "PAYMENT_CHARGEBACK_REQUESTED"}


@router.post("/api/webhooks/asaas")
async def asaas_webhook(request: Request, asaas_access_token: str | None = Header(default=None)):
    if settings.ASAAS_WEBHOOK_TOKEN and asaas_access_token != settings.ASAAS_WEBHOOK_TOKEN:
        raise HTTPException(status_code=401, detail="Token de webhook inválido")

    body = await request.json()
    event = body.get("event", "")
    payment = body.get("payment") or {}
    payment_id = payment.get("id")
    if not payment_id:
        return {"received": True}

    registration = await registrations_col().find_one({"asaas_payment_id": payment_id})
    if not registration:
        # Pode ser um evento de uma cobrança que não é nossa (mesma conta Asaas usada em outro lugar)
        return {"received": True}

    # Idempotência simples: se já processamos esse status, não faz nada de novo
    if event in CONFIRMED_EVENTS and registration["payment_status"] != PaymentStatus.paid.value:
        await registrations_col().update_one(
            {"_id": registration["_id"]},
            {"$set": {"payment_status": PaymentStatus.paid.value}},
        )
        registration["payment_status"] = PaymentStatus.paid.value
        await generate_and_send_tickets(registration)

    elif event in RELEASE_EVENTS and registration["payment_status"] == PaymentStatus.pending.value:
        new_status = PaymentStatus.refunded.value if "REFUND" in event or "CHARGEBACK" in event else PaymentStatus.expired.value
        await registrations_col().update_one(
            {"_id": registration["_id"]},
            {"$set": {"payment_status": new_status}},
        )
        await batches_col().update_one(
            {"_id": _oid(registration["batch_id"])},
            {"$inc": {"quantity_sold": -registration["quantity"]}},
        )
        await notify_waitlist_for_batch(registration["batch_id"], registration["quantity"])

    return {"received": True}
