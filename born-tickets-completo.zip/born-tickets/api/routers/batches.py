from datetime import datetime, timezone
from bson import ObjectId
from fastapi import APIRouter, HTTPException, Depends

from ..models import BatchCreate, BatchUpdate, BatchOut, BatchStatus, serialize_doc
from ..database import batches_col
from ..auth import get_current_admin
from .events import _oid

router = APIRouter(tags=["batches"])


def _to_batch_out(doc: dict) -> dict:
    doc = serialize_doc(doc)
    doc["quantity_available"] = max(0, doc["quantity_total"] - doc["quantity_sold"])
    if doc["quantity_available"] == 0 and doc["status"] == BatchStatus.active.value:
        doc["status"] = BatchStatus.soldout.value
    return doc


# ---------- Público ----------

@router.get("/api/events/{event_id}/batches", response_model=list[BatchOut])
async def list_public_batches(event_id: str):
    cursor = batches_col().find({"event_id": event_id})
    return [_to_batch_out(doc) async for doc in cursor]


# ---------- Admin ----------

@router.get("/api/admin/events/{event_id}/batches", response_model=list[BatchOut])
async def admin_list_batches(event_id: str, admin=Depends(get_current_admin)):
    cursor = batches_col().find({"event_id": event_id})
    return [_to_batch_out(doc) async for doc in cursor]


@router.post("/api/admin/batches", response_model=BatchOut, status_code=201)
async def admin_create_batch(data: BatchCreate, admin=Depends(get_current_admin)):
    doc = data.model_dump()
    doc["quantity_sold"] = 0
    doc["status"] = BatchStatus.active.value
    result = await batches_col().insert_one(doc)
    created = await batches_col().find_one({"_id": result.inserted_id})
    return _to_batch_out(created)


@router.put("/api/admin/batches/{batch_id}", response_model=BatchOut)
async def admin_update_batch(batch_id: str, data: BatchUpdate, admin=Depends(get_current_admin)):
    updates = {k: v for k, v in data.model_dump(exclude_unset=True).items() if v is not None}
    if "status" in updates and hasattr(updates["status"], "value"):
        updates["status"] = updates["status"].value

    result = await batches_col().update_one({"_id": _oid(batch_id)}, {"$set": updates})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Lote não encontrado")

    updated = await batches_col().find_one({"_id": _oid(batch_id)})
    return _to_batch_out(updated)


@router.delete("/api/admin/batches/{batch_id}", status_code=204)
async def admin_delete_batch(batch_id: str, admin=Depends(get_current_admin)):
    result = await batches_col().delete_one({"_id": _oid(batch_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Lote não encontrado")
    return None
