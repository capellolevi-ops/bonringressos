from datetime import datetime, timezone
from fastapi import APIRouter, Depends

from ..models import WaitlistCreate, WaitlistOut, WaitlistStatus, serialize_doc
from ..database import waitlist_col, events_col, batches_col
from ..auth import get_current_admin
from ..email_service import send_email
from .events import _oid

router = APIRouter(tags=["waitlist"])


@router.post("/api/waitlist", response_model=WaitlistOut, status_code=201)
async def join_waitlist(data: WaitlistCreate):
    doc = data.model_dump()
    doc["status"] = WaitlistStatus.waiting.value
    doc["created_at"] = datetime.now(timezone.utc)
    result = await waitlist_col().insert_one(doc)
    created = await waitlist_col().find_one({"_id": result.inserted_id})
    return serialize_doc(created)


@router.get("/api/admin/waitlist", response_model=list[WaitlistOut])
async def admin_list_waitlist(event_id: str | None = None, admin=Depends(get_current_admin)):
    query = {"event_id": event_id} if event_id else {}
    cursor = waitlist_col().find(query).sort("created_at", 1)
    return [serialize_doc(doc) async for doc in cursor]


async def notify_waitlist_for_batch(batch_id: str, freed_quantity: int):
    """
    Chamado quando vagas voltam pra um lote (pagamento expirado/cancelado).
    Convoca por e-mail as pessoas na fila, na ordem de chegada, até esgotar as vagas liberadas.
    """
    batch = await batches_col().find_one({"_id": _oid(batch_id)})
    if not batch:
        return

    remaining = freed_quantity
    cursor = waitlist_col().find({"batch_id": batch_id, "status": WaitlistStatus.waiting.value}).sort("created_at", 1)
    async for entry in cursor:
        if remaining <= 0:
            break
        if entry["quantity_wanted"] > remaining:
            continue

        event = await events_col().find_one({"_id": _oid(entry["event_id"])})
        event_title = event["title"] if event else "o evento"

        html = f"""
        <div style="font-family:Poppins,Arial,sans-serif;background:#09090b;padding:32px;color:#f6f3ec;">
          <div style="max-width:480px;margin:0 auto;">
            <p style="letter-spacing:.08em;color:#cda45e;font-size:13px;margin:0 0 4px;">BORN CHURCH</p>
            <h1 style="font-family:Georgia,serif;font-size:24px;margin:0 0 16px;">Uma vaga abriu! 🎉</h1>
            <p style="color:#cecac1;line-height:1.6;">Olá, {entry['name']}! Uma vaga para <strong>{event_title}</strong> acabou de ficar disponível.
            Entre no site e finalize sua inscrição — é por ordem de chegada, então não demore.</p>
          </div>
        </div>
        """
        sent = await send_email(to=entry["email"], subject=f"Vaga disponível — {event_title}", html=html)
        if sent:
            await waitlist_col().update_one(
                {"_id": entry["_id"]},
                {"$set": {"status": WaitlistStatus.notified.value, "notified_at": datetime.now(timezone.utc)}},
            )
            remaining -= entry["quantity_wanted"]
