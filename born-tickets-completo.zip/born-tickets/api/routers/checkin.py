from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException, Depends

from ..models import CheckInRequest, TicketOut, serialize_doc
from ..database import tickets_col
from ..auth import get_current_admin

router = APIRouter(tags=["checkin"])


@router.post("/api/admin/checkin")
async def check_in(data: CheckInRequest, admin=Depends(get_current_admin)):
    ticket = await tickets_col().find_one({"qr_token": data.qr_token})
    if not ticket:
        raise HTTPException(status_code=404, detail="Ingresso não encontrado. QR Code inválido.")

    if ticket["checked_in"]:
        return {
            "status": "already_checked_in",
            "attendee_name": ticket["attendee_name"],
            "checked_in_at": ticket["checked_in_at"],
        }

    now = datetime.now(timezone.utc)
    await tickets_col().update_one(
        {"_id": ticket["_id"]},
        {"$set": {"checked_in": True, "checked_in_at": now, "checked_in_by": admin.get("email")}},
    )
    return {"status": "ok", "attendee_name": ticket["attendee_name"], "checked_in_at": now}


@router.get("/api/admin/tickets", response_model=list[TicketOut])
async def admin_list_tickets(event_id: str, admin=Depends(get_current_admin)):
    cursor = tickets_col().find({"event_id": event_id}).sort("attendee_name", 1)
    return [serialize_doc(doc) async for doc in cursor]
