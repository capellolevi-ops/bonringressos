from fastapi import APIRouter, HTTPException, status

from ..models import AdminLogin
from ..database import admins_col
from ..auth import verify_password, create_access_token

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login")
async def login(data: AdminLogin):
    admin = await admins_col().find_one({"email": data.email})
    if not admin or not verify_password(data.password, admin["password_hash"]):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="E-mail ou senha incorretos")

    token = create_access_token(str(admin["_id"]), admin["email"])
    return {
        "access_token": token,
        "token_type": "bearer",
        "admin": {"id": str(admin["_id"]), "email": admin["email"], "name": admin.get("name", "Admin")},
    }
