"""
Endpoint de configuração inicial — visite essa URL UMA vez no navegador
depois de publicar o site, pra criar o admin sem precisar rodar nada no computador.
"""
from fastapi import APIRouter, HTTPException

from ..config import settings
from ..database import admins_col, events_col, batches_col, registrations_col, tickets_col, waitlist_col
from ..auth import hash_password

router = APIRouter(tags=["setup"])

DEFAULT_ADMIN_EMAIL = "admin@bornchurch.com.br"
DEFAULT_ADMIN_PASSWORD = "LEqIEUQCoAzmZv"


@router.get("/api/setup")
async def run_setup(token: str):
    if not settings.SETUP_TOKEN or token != settings.SETUP_TOKEN:
        raise HTTPException(status_code=401, detail="Token de configuração inválido")

    existing = await admins_col().find_one({"email": DEFAULT_ADMIN_EMAIL})
    if existing:
        message = f"Admin '{DEFAULT_ADMIN_EMAIL}' já existia — nada foi alterado."
    else:
        await admins_col().insert_one({
            "email": DEFAULT_ADMIN_EMAIL,
            "password_hash": hash_password(DEFAULT_ADMIN_PASSWORD),
            "name": "Administrador",
        })
        message = "Admin criado com sucesso."

    await events_col().create_index("status")
    await events_col().create_index("start_date")
    await batches_col().create_index("event_id")
    await registrations_col().create_index("event_id")
    await registrations_col().create_index("buyer_email")
    await registrations_col().create_index("asaas_payment_id")
    await tickets_col().create_index("qr_token", unique=True)
    await tickets_col().create_index("event_id")
    await waitlist_col().create_index("event_id")
    await waitlist_col().create_index("status")

    return {
        "message": message,
        "admin_email": DEFAULT_ADMIN_EMAIL,
        "admin_password": DEFAULT_ADMIN_PASSWORD if not existing else "(já existia, não foi alterada)",
        "next_step": "Troque essa senha assim que fizer login em /admin/login — e não visite essa URL de novo.",
    }
