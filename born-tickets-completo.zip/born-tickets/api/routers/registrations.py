from datetime import datetime, timezone, timedelta
from bson import ObjectId
from fastapi import APIRouter, HTTPException, Depends, status

from ..models import RegistrationCreate, RegistrationOut, PaymentStatus, PaymentMethod, serialize_doc
from ..database import registrations_col, batches_col, events_col
from ..auth import get_current_admin
from .events import _oid
from .. import asaas_client

router = APIRouter(tags=["registrations"])


async def _reserve_batch_quantity(batch_id: str, qty: int) -> dict:
    """Reserva 'qty' vagas de forma atômica. Levanta 409 se não houver disponibilidade."""
    batch_oid = _oid(batch_id)
    batch = await batches_col().find_one({"_id": batch_oid})
    if not batch:
        raise HTTPException(status_code=404, detail="Lote não encontrado")

    result = await batches_col().find_one_and_update(
        {
            "_id": batch_oid,
            "status": "active",
            "$expr": {"$lte": [{"$add": ["$quantity_sold", qty]}, "$quantity_total"]},
        },
        {"$inc": {"quantity_sold": qty}},
    )
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Não há vagas suficientes nesse lote. Entre na lista de espera.",
        )
    return batch


async def _release_batch_quantity(batch_id: str, qty: int):
    await batches_col().update_one({"_id": _oid(batch_id)}, {"$inc": {"quantity_sold": -qty}})


@router.post("/api/registrations", response_model=RegistrationOut, status_code=201)
async def create_registration(data: RegistrationCreate):
    event = await events_col().find_one({"_id": _oid(data.event_id), "status": "published"})
    if not event:
        raise HTTPException(status_code=404, detail="Evento não encontrado")

    batch = await _reserve_batch_quantity(data.batch_id, data.quantity)

    attendees = data.attendees
    if not attendees:
        attendees = [{"name": data.buyer_name, "document": data.buyer_document, "email": data.buyer_email}]
    if len(attendees) != data.quantity:
        await _release_batch_quantity(data.batch_id, data.quantity)
        raise HTTPException(status_code=400, detail="O número de participantes não bate com a quantidade informada")

    total_amount = round(batch["price"] * data.quantity, 2)
    now = datetime.now(timezone.utc)

    reg_doc = {
        "event_id": data.event_id,
        "batch_id": data.batch_id,
        "buyer_name": data.buyer_name,
        "buyer_email": data.buyer_email,
        "buyer_phone": data.buyer_phone,
        "buyer_document": data.buyer_document,
        "quantity": data.quantity,
        "attendees": [a.model_dump() if hasattr(a, "model_dump") else a for a in attendees],
        "total_amount": total_amount,
        "payment_status": PaymentStatus.pending.value,
        "payment_method": data.payment_method.value,
        "asaas_payment_id": None,
        "pix_qr_code": None,
        "pix_copy_paste": None,
        "card_checkout_url": None,
        "created_at": now,
    }
    result = await registrations_col().insert_one(reg_doc)
    reg_id = str(result.inserted_id)

    try:
        customer_id = await asaas_client.find_or_create_customer(
            data.buyer_name, data.buyer_email, data.buyer_phone, data.buyer_document
        )
        due_date = (now + timedelta(days=1)).strftime("%Y-%m-%d") if data.payment_method == PaymentMethod.pix \
            else (now + timedelta(days=3)).strftime("%Y-%m-%d")
        billing_type = "PIX" if data.payment_method == PaymentMethod.pix else "CREDIT_CARD"

        payment = await asaas_client.create_payment(
            customer_id=customer_id,
            value=total_amount,
            description=f"Ingresso(s) — {event['title']}",
            billing_type=billing_type,
            due_date=due_date,
            external_reference=reg_id,
        )

        update = {"asaas_payment_id": payment["id"]}
        if billing_type == "PIX":
            pix = await asaas_client.get_pix_qr_code(payment["id"])
            update["pix_qr_code"] = pix.get("encodedImage")
            update["pix_copy_paste"] = pix.get("payload")
        else:
            update["card_checkout_url"] = payment.get("invoiceUrl")

        await registrations_col().update_one({"_id": result.inserted_id}, {"$set": update})
        reg_doc.update(update)

    except Exception:
        # Se o Asaas falhar, libera as vagas reservadas e remove a inscrição pendente
        await _release_batch_quantity(data.batch_id, data.quantity)
        await registrations_col().delete_one({"_id": result.inserted_id})
        raise HTTPException(status_code=502, detail="Não foi possível gerar o pagamento. Tente novamente.")

    reg_doc["id"] = reg_id
    return reg_doc


@router.get("/api/registrations/{registration_id}", response_model=RegistrationOut)
async def get_registration_status(registration_id: str):
    """Usado pela página do participante para checar se o pagamento já confirmou."""
    doc = await registrations_col().find_one({"_id": _oid(registration_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Inscrição não encontrada")
    return serialize_doc(doc)


@router.get("/api/admin/registrations", response_model=list[RegistrationOut])
async def admin_list_registrations(event_id: str | None = None, admin=Depends(get_current_admin)):
    query = {"event_id": event_id} if event_id else {}
    cursor = registrations_col().find(query).sort("created_at", -1)
    return [serialize_doc(doc) async for doc in cursor]
