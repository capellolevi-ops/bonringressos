from datetime import datetime, timezone
from bson import ObjectId
from bson.errors import InvalidId
from fastapi import APIRouter, HTTPException, Depends, status

from ..models import EventCreate, EventUpdate, EventOut, EventStatus, serialize_doc
from ..database import events_col
from ..auth import get_current_admin

router = APIRouter(tags=["events"])


def _oid(id_str: str) -> ObjectId:
    try:
        return ObjectId(id_str)
    except InvalidId:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="ID inválido")


# ---------- Público ----------

@router.get("/api/events", response_model=list[EventOut])
async def list_public_events():
    """Lista apenas eventos publicados, ordenados por data mais próxima primeiro."""
    cursor = events_col().find({"status": EventStatus.published.value}).sort("start_date", 1)
    return [serialize_doc(doc) async for doc in cursor]


@router.get("/api/events/{event_id}", response_model=EventOut)
async def get_public_event(event_id: str):
    doc = await events_col().find_one({"_id": _oid(event_id), "status": EventStatus.published.value})
    if not doc:
        raise HTTPException(status_code=404, detail="Evento não encontrado")
    return serialize_doc(doc)


# ---------- Admin ----------

@router.get("/api/admin/events", response_model=list[EventOut])
async def admin_list_events(admin=Depends(get_current_admin)):
    cursor = events_col().find({}).sort("start_date", 1)
    return [serialize_doc(doc) async for doc in cursor]


@router.get("/api/admin/events/{event_id}", response_model=EventOut)
async def admin_get_event(event_id: str, admin=Depends(get_current_admin)):
    doc = await events_col().find_one({"_id": _oid(event_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Evento não encontrado")
    return serialize_doc(doc)


@router.post("/api/admin/events", response_model=EventOut, status_code=201)
async def admin_create_event(data: EventCreate, admin=Depends(get_current_admin)):
    now = datetime.now(timezone.utc)
    doc = data.model_dump()
    doc["status"] = data.status.value
    doc["created_at"] = now
    doc["updated_at"] = now
    result = await events_col().insert_one(doc)
    created = await events_col().find_one({"_id": result.inserted_id})
    return serialize_doc(created)


@router.put("/api/admin/events/{event_id}", response_model=EventOut)
async def admin_update_event(event_id: str, data: EventUpdate, admin=Depends(get_current_admin)):
    updates = {k: v for k, v in data.model_dump(exclude_unset=True).items() if v is not None}
    if "status" in updates:
        updates["status"] = updates["status"].value if hasattr(updates["status"], "value") else updates["status"]
    updates["updated_at"] = datetime.now(timezone.utc)

    result = await events_col().update_one({"_id": _oid(event_id)}, {"$set": updates})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Evento não encontrado")

    updated = await events_col().find_one({"_id": _oid(event_id)})
    return serialize_doc(updated)


@router.delete("/api/admin/events/{event_id}", status_code=204)
async def admin_delete_event(event_id: str, admin=Depends(get_current_admin)):
    result = await events_col().delete_one({"_id": _oid(event_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Evento não encontrado")
    return None
