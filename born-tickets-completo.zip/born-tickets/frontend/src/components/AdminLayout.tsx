import { ReactNode } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { getToken, clearToken } from '../api'

export function RequireAuth({ children }: { children: ReactNode }) {
  if (!getToken()) {
    return <Navigate to="/admin/login" replace />
  }
  return <>{children}</>
}

export default function AdminLayout({ children }: { children: ReactNode }) {
  const navigate = useNavigate()

  function logout() {
    clearToken()
    navigate('/admin/login')
  }

  return (
    <div className="min-h-screen flex">
      <aside className="w-56 border-r border-border p-6 flex flex-col gap-6 shrink-0">
        <Link to="/admin" className="font-display text-lg">
          Born Church
        </Link>
        <nav className="flex flex-col gap-1 text-sm">
          <Link to="/admin" className="px-3 py-2 rounded-lg hover:bg-surface transition-colors">
            Eventos
          </Link>
        </nav>
        <button onClick={logout} className="mt-auto text-sm text-muted hover:text-ink text-left">
          Sair
        </button>
      </aside>
      <main className="flex-1 p-8 overflow-y-auto">{children}</main>
    </div>
  )
}
