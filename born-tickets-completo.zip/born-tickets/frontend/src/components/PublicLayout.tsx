import { ReactNode } from 'react'
import { Link } from 'react-router-dom'

export default function PublicLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-border sticky top-0 z-40 bg-bg/85 backdrop-blur">
        <div className="max-w-5xl mx-auto px-5 py-4 flex items-center justify-between">
          <Link to="/" className="font-display text-lg tracking-wide">
            Born Church <span className="text-gold">Ingressos</span>
          </Link>
        </div>
      </header>
      <main className="flex-1">{children}</main>
      <footer className="border-t border-border py-8 text-center text-sm text-muted">
        Born Church — Pinhais, PR
      </footer>
    </div>
  )
}
