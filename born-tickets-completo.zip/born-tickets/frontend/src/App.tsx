import { BrowserRouter, Routes, Route } from 'react-router-dom'
import EventsListPage from './pages/EventsListPage'
import EventDetailPage from './pages/EventDetailPage'
import PaymentPage from './pages/PaymentPage'
import LoginPage from './pages/admin/LoginPage'
import DashboardPage from './pages/admin/DashboardPage'
import EventFormPage from './pages/admin/EventFormPage'
import CheckinPage from './pages/admin/CheckinPage'
import { RequireAuth } from './components/AdminLayout'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<EventsListPage />} />
        <Route path="/eventos/:id" element={<EventDetailPage />} />
        <Route path="/pagamento/:id" element={<PaymentPage />} />

        <Route path="/admin/login" element={<LoginPage />} />
        <Route
          path="/admin"
          element={
            <RequireAuth>
              <DashboardPage />
            </RequireAuth>
          }
        />
        <Route
          path="/admin/eventos/:id"
          element={
            <RequireAuth>
              <EventFormPage />
            </RequireAuth>
          }
        />
        <Route
          path="/admin/checkin/:eventId"
          element={
            <RequireAuth>
              <CheckinPage />
            </RequireAuth>
          }
        />
      </Routes>
    </BrowserRouter>
  )
}
