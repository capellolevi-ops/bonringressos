import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../../api'
import { EventItem } from '../../types'
import AdminLayout from '../../components/AdminLayout'

const statusLabel: Record<string, string> = {
  draft: 'Rascunho',
  published: 'Publicado',
  closed: 'Encerrado',
  cancelled: 'Cancelado',
}

export default function DashboardPage() {
  const [events, setEvents] = useState<EventItem[]>([])

  useEffect(() => {
    api.get<EventItem[]>('/admin/events').then(setEvents)
  }, [])

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display text-2xl">Eventos</h1>
        <Link to="/admin/eventos/novo" className="btn-gold">
          + Novo evento
        </Link>
      </div>

      <div className="grid gap-3">
        {events.map((ev) => (
          <Link key={ev.id} to={`/admin/eventos/${ev.id}`} className="card p-4 flex items-center justify-between">
            <div>
              <p className="font-semibold">{ev.title}</p>
              <p className="text-sm text-muted">
                {new Date(ev.start_date).toLocaleDateString('pt-BR')} · {ev.location}
              </p>
            </div>
            <span className="text-xs px-3 py-1 rounded-full border border-border text-muted">
              {statusLabel[ev.status]}
            </span>
          </Link>
        ))}
        {events.length === 0 && <p className="text-muted">Nenhum evento criado ainda.</p>}
      </div>
    </AdminLayout>
  )
}
