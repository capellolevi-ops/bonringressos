import type { FormEvent } from 'react'
import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { api, ApiError } from '../../api'
import { Batch, EventItem, EventStatus, Registration } from '../../types'
import AdminLayout from '../../components/AdminLayout'

const emptyEvent = {
  title: '',
  description: '',
  start_date: '',
  end_date: '',
  location: '',
  image_url: '',
  status: 'draft' as EventStatus,
}

export default function EventFormPage() {
  const { id } = useParams<{ id: string }>()
  const isNew = id === 'novo'
  const navigate = useNavigate()

  const [form, setForm] = useState(emptyEvent)
  const [eventId, setEventId] = useState<string | null>(isNew ? null : id ?? null)
  const [batches, setBatches] = useState<Batch[]>([])
  const [registrations, setRegistrations] = useState<Registration[]>([])
  const [newBatch, setNewBatch] = useState({ name: '', price: '0', quantity_total: '100', max_per_purchase: '10' })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (isNew || !id) return
    loadEvent(id)
    loadBatches(id)
    loadRegistrations(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id])

  async function loadEvent(evId: string) {
    try {
      const ev = await api.get<EventItem>(`/admin/events/${evId}`)
      setEventId(ev.id)
      setForm({
        title: ev.title,
        description: ev.description,
        start_date: ev.start_date.slice(0, 16),
        end_date: ev.end_date ? ev.end_date.slice(0, 16) : '',
        location: ev.location,
        image_url: ev.image_url || '',
        status: ev.status,
      })
    } catch {
      /* ignore */
    }
  }

  async function loadBatches(evId: string) {
    setBatches(await api.get<Batch[]>(`/admin/events/${evId}/batches`))
  }

  async function loadRegistrations(evId: string) {
    setRegistrations(await api.get<Registration[]>(`/admin/registrations?event_id=${evId}`))
  }

  async function handleSaveEvent(e: FormEvent) {
    e.preventDefault()
    setSaving(true)
    setError('')
    const payload = {
      ...form,
      start_date: new Date(form.start_date).toISOString(),
      end_date: form.end_date ? new Date(form.end_date).toISOString() : null,
      image_url: form.image_url || null,
    }
    try {
      if (isNew) {
        const created = await api.post<EventItem>('/admin/events', payload)
        setEventId(created.id)
        navigate(`/admin/eventos/${created.id}`, { replace: true })
      } else if (eventId) {
        await api.put<EventItem>(`/admin/events/${eventId}`, payload)
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Erro ao salvar evento.')
    } finally {
      setSaving(false)
    }
  }

  async function handleAddBatch(e: FormEvent) {
    e.preventDefault()
    if (!eventId) return
    await api.post('/admin/batches', {
      event_id: eventId,
      name: newBatch.name,
      price: Number(newBatch.price),
      quantity_total: Number(newBatch.quantity_total),
      max_per_purchase: Number(newBatch.max_per_purchase),
    })
    setNewBatch({ name: '', price: '0', quantity_total: '100', max_per_purchase: '10' })
    loadBatches(eventId)
  }

  async function handleDeleteBatch(batchId: string) {
    if (!eventId) return
    await api.delete(`/admin/batches/${batchId}`)
    loadBatches(eventId)
  }

  return (
    <AdminLayout>
      <Link to="/admin" className="text-sm text-muted hover:text-ink">
        ← Voltar
      </Link>

      <form onSubmit={handleSaveEvent} className="card p-6 space-y-4 mt-4 max-w-2xl">
        <h1 className="font-display text-xl">{isNew ? 'Novo evento' : 'Editar evento'}</h1>

        <div>
          <label className="label">Título</label>
          <input required className="input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        </div>
        <div>
          <label className="label">Descrição</label>
          <textarea
            className="input min-h-[100px]"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Início</label>
            <input
              required
              type="datetime-local"
              className="input"
              value={form.start_date}
              onChange={(e) => setForm({ ...form, start_date: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Fim (opcional)</label>
            <input
              type="datetime-local"
              className="input"
              value={form.end_date}
              onChange={(e) => setForm({ ...form, end_date: e.target.value })}
            />
          </div>
        </div>
        <div>
          <label className="label">Local</label>
          <input required className="input" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
        </div>
        <div>
          <label className="label">URL da imagem (opcional)</label>
          <input className="input" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} />
        </div>
        <div>
          <label className="label">Status</label>
          <select
            className="input"
            value={form.status}
            onChange={(e) => setForm({ ...form, status: e.target.value as EventStatus })}
          >
            <option value="draft">Rascunho</option>
            <option value="published">Publicado</option>
            <option value="closed">Encerrado</option>
            <option value="cancelled">Cancelado</option>
          </select>
        </div>

        {error && <p className="text-sm text-red-400">{error}</p>}
        <button type="submit" disabled={saving} className="btn-gold">
          {saving ? 'Salvando...' : 'Salvar evento'}
        </button>
      </form>

      {eventId && (
        <>
          <div className="card p-6 mt-8 max-w-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl">Lotes de ingresso</h2>
              <Link to={`/admin/checkin/${eventId}`} className="btn-outline text-sm">
                Abrir check-in
              </Link>
            </div>

            <div className="space-y-2">
              {batches.map((b) => (
                <div key={b.id} className="flex items-center justify-between border border-border rounded-xl p-3">
                  <div>
                    <p className="font-medium">{b.name}</p>
                    <p className="text-sm text-muted">
                      R$ {b.price.toFixed(2)} · {b.quantity_sold}/{b.quantity_total} vendidos · {b.status}
                    </p>
                  </div>
                  <button onClick={() => handleDeleteBatch(b.id)} className="text-sm text-red-400 hover:underline">
                    Excluir
                  </button>
                </div>
              ))}
            </div>

            <form onSubmit={handleAddBatch} className="grid grid-cols-2 gap-3 pt-3 border-t border-border">
              <input
                required
                placeholder="Nome do lote"
                className="input col-span-2"
                value={newBatch.name}
                onChange={(e) => setNewBatch({ ...newBatch, name: e.target.value })}
              />
              <input
                required
                type="number"
                step="0.01"
                placeholder="Preço"
                className="input"
                value={newBatch.price}
                onChange={(e) => setNewBatch({ ...newBatch, price: e.target.value })}
              />
              <input
                required
                type="number"
                placeholder="Quantidade"
                className="input"
                value={newBatch.quantity_total}
                onChange={(e) => setNewBatch({ ...newBatch, quantity_total: e.target.value })}
              />
              <button type="submit" className="btn-gold col-span-2">
                + Adicionar lote
              </button>
            </form>
          </div>

          <div className="card p-6 mt-8 max-w-3xl">
            <h2 className="font-display text-xl mb-4">Inscrições ({registrations.length})</h2>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {registrations.map((r) => (
                <div key={r.id} className="flex items-center justify-between border-b border-border py-2 text-sm">
                  <div>
                    <p className="font-medium">{r.buyer_name}</p>
                    <p className="text-muted">
                      {r.buyer_email} · {r.quantity}x · R$ {r.total_amount.toFixed(2)}
                    </p>
                  </div>
                  <span
                    className={`text-xs px-3 py-1 rounded-full border ${
                      r.payment_status === 'paid' ? 'border-gold text-gold' : 'border-border text-muted'
                    }`}
                  >
                    {r.payment_status}
                  </span>
                </div>
              ))}
              {registrations.length === 0 && <p className="text-muted text-sm">Nenhuma inscrição ainda.</p>}
            </div>
          </div>
        </>
      )}
    </AdminLayout>
  )
}
