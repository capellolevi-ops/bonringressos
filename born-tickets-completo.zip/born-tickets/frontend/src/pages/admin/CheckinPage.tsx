import { useEffect, useRef, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import QrScanner from 'qr-scanner'
import { api } from '../../api'
import AdminLayout from '../../components/AdminLayout'

interface CheckinResult {
  status: 'ok' | 'already_checked_in' | 'error'
  attendee_name?: string
  message?: string
}

export default function CheckinPage() {
  const { eventId } = useParams<{ eventId: string }>()
  const videoRef = useRef<HTMLVideoElement>(null)
  const scannerRef = useRef<QrScanner | null>(null)
  const [result, setResult] = useState<CheckinResult | null>(null)
  const [scanning, setScanning] = useState(false)
  const busyRef = useRef(false)

  useEffect(() => {
    if (!videoRef.current) return

    const scanner = new QrScanner(
      videoRef.current,
      async (result) => {
        if (busyRef.current) return
        busyRef.current = true
        await handleScan(result.data)
        setTimeout(() => {
          busyRef.current = false
        }, 1500)
      },
      { highlightScanRegion: true, highlightCodeOutline: true },
    )
    scannerRef.current = scanner
    scanner
      .start()
      .then(() => setScanning(true))
      .catch(() => setScanning(false))

    return () => {
      scanner.stop()
      scanner.destroy()
    }
  }, [])

  async function handleScan(qrToken: string) {
    try {
      const res = await api.post<{ status: string; attendee_name: string }>('/admin/checkin', { qr_token: qrToken })
      setResult({
        status: res.status as 'ok' | 'already_checked_in',
        attendee_name: res.attendee_name,
      })
    } catch (err) {
      setResult({ status: 'error', message: err instanceof Error ? err.message : 'QR Code inválido' })
    }
  }

  return (
    <AdminLayout>
      <Link to={`/admin/eventos/${eventId}`} className="text-sm text-muted hover:text-ink">
        ← Voltar ao evento
      </Link>

      <h1 className="font-display text-2xl mt-4 mb-6">Check-in</h1>

      <div className="max-w-md">
        <div className="rounded-card overflow-hidden border border-border bg-black">
          <video ref={videoRef} className="w-full aspect-square object-cover" />
        </div>
        {!scanning && <p className="text-sm text-muted mt-3">Aguardando permissão da câmera...</p>}

        {result && (
          <div
            className={`card p-5 mt-5 text-center ${
              result.status === 'ok' ? 'border-gold' : result.status === 'already_checked_in' ? 'border-yellow-500' : 'border-red-500'
            }`}
          >
            {result.status === 'ok' && (
              <p className="text-xl font-semibold text-gold">✅ {result.attendee_name} — entrada liberada</p>
            )}
            {result.status === 'already_checked_in' && (
              <p className="text-xl font-semibold text-yellow-400">⚠️ {result.attendee_name} já fez check-in</p>
            )}
            {result.status === 'error' && <p className="text-xl font-semibold text-red-400">❌ {result.message}</p>}
          </div>
        )}
      </div>
    </AdminLayout>
  )
}
