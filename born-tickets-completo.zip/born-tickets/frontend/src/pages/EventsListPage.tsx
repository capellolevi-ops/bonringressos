import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api'
import { EventItem } from '../types'
import PublicLayout from '../components/PublicLayout'

export default function EventsListPage() {
  const [events, setEvents] = useState<EventItem[] | null>(null)

  useEffect(() => {
    api.get<EventItem[]>('/events').then(setEvents).catch(() => setEvents([]))
  }, [])

  return (
    <PublicLayout>
      <div className="max-w-5xl mx-auto px-5 py-16">
        <h1 className="font-display text-4xl mb-2">Próximos eventos</h1>
        <p className="text-muted mb-12">Garanta seu ingresso para os próximos eventos da Born Church.</p>

        {events === null && <p className="text-muted">Carregando eventos...</p>}
        {events?.length === 0 && <p className="text-muted">Nenhum evento disponível no momento.</p>}

        <div className="grid sm:grid-cols-2 gap-6">
          {events?.map((ev) => (
            <Link
              key={ev.id}
              to={`/eventos/${ev.id}`}
              className="card overflow-hidden group transition-transform hover:-translate-y-1"
            >
              {ev.image_url && (
                <div className="aspect-[16/9] overflow-hidden">
                  <img src={ev.image_url} alt={ev.title} className="w-full h-full object-cover" />
                </div>
              )}
              <div className="p-6">
                <p className="text-gold text-sm mb-1">
                  {new Date(ev.start_date).toLocaleDateString('pt-BR', {
                    day: '2-digit',
                    month: 'long',
                    year: 'numeric',
                  })}
                </p>
                <h2 className="font-display text-xl mb-2">{ev.title}</h2>
                <p className="text-muted text-sm">{ev.location}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </PublicLayout>
  )
}
