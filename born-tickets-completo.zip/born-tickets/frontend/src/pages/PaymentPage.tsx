import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { api } from '../api'
import { Registration } from '../types'
import PublicLayout from '../components/PublicLayout'

export default function PaymentPage() {
  const { id } = useParams<{ id: string }>()
  const [reg, setReg] = useState<Registration | null>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    if (!id) return
    let stop = false

    async function poll() {
      try {
        const data = await api.get<Registration>(`/registrations/${id}`)
        if (stop) return
        setReg(data)
        if (data.payment_status === 'pending') {
          setTimeout(poll, 4000)
        }
      } catch {
        if (!stop) setTimeout(poll, 6000)
      }
    }
    poll()
    return () => {
      stop = true
    }
  }, [id])

  function copyPix() {
    if (!reg?.pix_copy_paste) return
    navigator.clipboard.writeText(reg.pix_copy_paste)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  if (!reg) {
    return (
      <PublicLayout>
        <div className="max-w-md mx-auto px-5 py-24 text-center text-muted">Carregando...</div>
      </PublicLayout>
    )
  }

  if (reg.payment_status === 'paid') {
    return (
      <PublicLayout>
        <div className="max-w-md mx-auto px-5 py-24 text-center">
          <p className="text-5xl mb-4">🎉</p>
          <h1 className="font-display text-2xl mb-3">Pagamento confirmado!</h1>
          <p className="text-muted">
            Enviamos seu(s) ingresso(s) com QR Code para <strong className="text-ink">{reg.buyer_email}</strong>.
            Confira também a caixa de spam.
          </p>
        </div>
      </PublicLayout>
    )
  }

  if (reg.payment_status !== 'pending') {
    return (
      <PublicLayout>
        <div className="max-w-md mx-auto px-5 py-24 text-center">
          <h1 className="font-display text-2xl mb-3">Pagamento não concluído</h1>
          <p className="text-muted">Status: {reg.payment_status}. Volte ao evento para tentar novamente.</p>
        </div>
      </PublicLayout>
    )
  }

  return (
    <PublicLayout>
      <div className="max-w-md mx-auto px-5 py-16">
        <h1 className="font-display text-2xl mb-2">Finalize seu pagamento</h1>
        <p className="text-muted mb-8">
          Total: <span className="text-gold font-semibold">R$ {reg.total_amount.toFixed(2)}</span>
        </p>

        {reg.payment_method === 'pix' && reg.pix_qr_code && (
          <div className="card p-6 text-center space-y-5">
            <img
              src={`data:image/png;base64,${reg.pix_qr_code}`}
              alt="QR Code do PIX"
              className="w-56 h-56 mx-auto rounded-xl bg-white p-2"
            />
            <button onClick={copyPix} className="btn-outline w-full">
              {copied ? 'Copiado!' : 'Copiar código PIX'}
            </button>
            <p className="text-xs text-muted">
              Aguardando confirmação do pagamento — essa página atualiza sozinha assim que cair.
            </p>
          </div>
        )}

        {reg.payment_method === 'card' && reg.card_checkout_url && (
          <div className="card p-6 text-center space-y-5">
            <p className="text-muted">Finalize o pagamento com cartão na página segura do Asaas.</p>
            <a href={reg.card_checkout_url} target="_blank" rel="noreferrer" className="btn-gold w-full">
              Pagar com cartão
            </a>
            <p className="text-xs text-muted">Depois de pagar, volte pra essa aba — ela atualiza sozinha.</p>
          </div>
        )}
      </div>
    </PublicLayout>
  )
}
