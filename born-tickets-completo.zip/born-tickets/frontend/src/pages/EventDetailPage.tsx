import type { FormEvent } from 'react'
import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api, ApiError } from '../api'
import { Attendee, Batch, EventItem, PaymentMethod, Registration } from '../types'
import PublicLayout from '../components/PublicLayout'

export default function EventDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()

  const [event, setEvent] = useState<EventItem | null>(null)
  const [batches, setBatches] = useState<Batch[]>([])
  const [selectedBatch, setSelectedBatch] = useState<Batch | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [buyerName, setBuyerName] = useState('')
  const [buyerEmail, setBuyerEmail] = useState('')
  const [buyerPhone, setBuyerPhone] = useState('')
  const [buyerDocument, setBuyerDocument] = useState('')
  const [attendees, setAttendees] = useState<Attendee[]>([{ name: '' }])
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('pix')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [showWaitlist, setShowWaitlist] = useState(false)
  const [waitlistSent, setWaitlistSent] = useState(false)

  useEffect(() => {
    if (!id) return
    api.get<EventItem>(`/events/${id}`).then(setEvent).catch(() => setEvent(null))
    api.get<Batch[]>(`/events/${id}/batches`).then(setBatches).catch(() => setBatches([]))
  }, [id])

  function updateQuantity(q: number) {
    setQuantity(q)
    setAttendees((prev) => {
      const next = [...prev]
      while (next.length < q) next.push({ name: '' })
      return next.slice(0, q)
    })
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!selectedBatch || !id) return
    setSubmitting(true)
    setError('')
    try {
      const reg = await api.post<Registration>('/registrations', {
        event_id: id,
        batch_id: selectedBatch.id,
        buyer_name: buyerName,
        buyer_email: buyerEmail,
        buyer_phone: buyerPhone,
        buyer_document: buyerDocument || null,
        quantity,
        attendees: attendees.map((a) => ({ ...a, name: a.name || buyerName })),
        payment_method: paymentMethod,
      })
      navigate(`/pagamento/${reg.id}`)
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        setShowWaitlist(true)
      } else {
        setError(err instanceof Error ? err.message : 'Não foi possível concluir a inscrição.')
      }
    } finally {
      setSubmitting(false)
    }
  }

  async function handleWaitlist(e: FormEvent) {
    e.preventDefault()
    if (!id || !selectedBatch) return
    try {
      await api.post('/waitlist', {
        event_id: id,
        batch_id: selectedBatch.id,
        name: buyerName,
        email: buyerEmail,
        phone: buyerPhone,
        quantity_wanted: quantity,
      })
      setWaitlistSent(true)
    } catch {
      setError('Não foi possível entrar na lista de espera. Tente novamente.')
    }
  }

  if (!event) {
    return (
      <PublicLayout>
        <div className="max-w-2xl mx-auto px-5 py-24 text-center text-muted">Carregando...</div>
      </PublicLayout>
    )
  }

  return (
    <PublicLayout>
      <div className="max-w-2xl mx-auto px-5 py-14">
        {event.image_url && (
          <div className="aspect-[16/9] rounded-card overflow-hidden mb-8">
            <img src={event.image_url} alt={event.title} className="w-full h-full object-cover" />
          </div>
        )}
        <p className="text-gold text-sm mb-2">
          {new Date(event.start_date).toLocaleDateString('pt-BR', { dateStyle: 'full' })}
        </p>
        <h1 className="font-display text-3xl mb-3">{event.title}</h1>
        <p className="text-muted mb-1">📍 {event.location}</p>
        <p className="text-ink/90 leading-relaxed mt-6 mb-12 whitespace-pre-line">{event.description}</p>

        <h2 className="font-display text-2xl mb-4">Ingressos</h2>
        <div className="grid gap-3 mb-10">
          {batches.map((b) => (
            <button
              key={b.id}
              onClick={() => {
                setSelectedBatch(b)
                setShowWaitlist(false)
                setWaitlistSent(false)
              }}
              disabled={b.quantity_available === 0}
              className={`card p-4 text-left flex items-center justify-between transition-colors disabled:opacity-40 ${
                selectedBatch?.id === b.id ? 'border-gold' : ''
              }`}
            >
              <div>
                <p className="font-semibold">{b.name}</p>
                <p className="text-sm text-muted">
                  {b.quantity_available === 0 ? 'Esgotado' : `${b.quantity_available} disponíveis`}
                </p>
              </div>
              <p className="font-display text-lg text-gold">
                {b.price === 0 ? 'Grátis' : `R$ ${b.price.toFixed(2)}`}
              </p>
            </button>
          ))}
        </div>

        {selectedBatch && !showWaitlist && (
          <form onSubmit={handleSubmit} className="card p-6 space-y-5">
            <h3 className="font-display text-xl">Seus dados</h3>

            <div>
              <label className="label">Quantidade</label>
              <input
                type="number"
                min={1}
                max={selectedBatch.max_per_purchase}
                value={quantity}
                onChange={(e) => updateQuantity(Number(e.target.value))}
                className="input"
              />
            </div>

            <div>
              <label className="label">Nome completo</label>
              <input required className="input" value={buyerName} onChange={(e) => setBuyerName(e.target.value)} />
            </div>
            <div>
              <label className="label">E-mail</label>
              <input
                required
                type="email"
                className="input"
                value={buyerEmail}
                onChange={(e) => setBuyerEmail(e.target.value)}
              />
            </div>
            <div>
              <label className="label">Telefone (WhatsApp)</label>
              <input required className="input" value={buyerPhone} onChange={(e) => setBuyerPhone(e.target.value)} />
            </div>
            <div>
              <label className="label">CPF (opcional)</label>
              <input className="input" value={buyerDocument} onChange={(e) => setBuyerDocument(e.target.value)} />
            </div>

            {quantity > 1 && (
              <div className="space-y-3 pt-2 border-t border-border">
                <p className="label !mb-0 pt-3">Nome de cada participante</p>
                {attendees.map((a, i) => (
                  <input
                    key={i}
                    required
                    placeholder={`Participante ${i + 1}`}
                    className="input"
                    value={a.name}
                    onChange={(e) => {
                      const next = [...attendees]
                      next[i] = { ...next[i], name: e.target.value }
                      setAttendees(next)
                    }}
                  />
                ))}
              </div>
            )}

            <div>
              <label className="label">Forma de pagamento</label>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('pix')}
                  className={`flex-1 rounded-xl border py-3 font-semibold transition-colors ${
                    paymentMethod === 'pix' ? 'border-gold text-gold' : 'border-border'
                  }`}
                >
                  PIX
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`flex-1 rounded-xl border py-3 font-semibold transition-colors ${
                    paymentMethod === 'card' ? 'border-gold text-gold' : 'border-border'
                  }`}
                >
                  Cartão
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <p className="text-muted">Total</p>
              <p className="font-display text-2xl text-gold">
                R$ {(selectedBatch.price * quantity).toFixed(2)}
              </p>
            </div>

            {error && <p className="text-sm text-red-400">{error}</p>}

            <button type="submit" disabled={submitting} className="btn-gold w-full">
              {submitting ? 'Processando...' : 'Continuar para pagamento'}
            </button>
          </form>
        )}

        {showWaitlist && !waitlistSent && (
          <form onSubmit={handleWaitlist} className="card p-6 space-y-5">
            <h3 className="font-display text-xl">Esse lote esgotou</h3>
            <p className="text-muted text-sm">
              Deixe seus dados e avisamos por e-mail assim que uma vaga abrir.
            </p>
            <input required placeholder="Nome" className="input" value={buyerName} onChange={(e) => setBuyerName(e.target.value)} />
            <input
              required
              type="email"
              placeholder="E-mail"
              className="input"
              value={buyerEmail}
              onChange={(e) => setBuyerEmail(e.target.value)}
            />
            <input
              required
              placeholder="Telefone"
              className="input"
              value={buyerPhone}
              onChange={(e) => setBuyerPhone(e.target.value)}
            />
            {error && <p className="text-sm text-red-400">{error}</p>}
            <button type="submit" className="btn-gold w-full">
              Entrar na lista de espera
            </button>
          </form>
        )}

        {waitlistSent && (
          <div className="card p-6 text-center">
            <p className="font-semibold mb-1">Você está na lista! ✅</p>
            <p className="text-muted text-sm">Avisamos por e-mail assim que uma vaga abrir.</p>
          </div>
        )}
      </div>
    </PublicLayout>
  )
}
