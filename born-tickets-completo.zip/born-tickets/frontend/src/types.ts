export type EventStatus = 'draft' | 'published' | 'closed' | 'cancelled'
export type BatchStatus = 'active' | 'soldout' | 'closed'
export type PaymentStatus = 'pending' | 'paid' | 'expired' | 'cancelled' | 'refunded'
export type PaymentMethod = 'pix' | 'card'
export type WaitlistStatus = 'waiting' | 'notified' | 'converted' | 'expired'

export interface EventItem {
  id: string
  title: string
  description: string
  start_date: string
  end_date: string | null
  location: string
  image_url: string | null
  status: EventStatus
  created_at: string
  updated_at: string
}

export interface Batch {
  id: string
  event_id: string
  name: string
  price: number
  quantity_total: number
  quantity_sold: number
  quantity_available: number
  sale_start: string | null
  sale_end: string | null
  max_per_purchase: number
  status: BatchStatus
}

export interface Attendee {
  name: string
  document?: string | null
  email?: string | null
}

export interface Registration {
  id: string
  event_id: string
  batch_id: string
  buyer_name: string
  buyer_email: string
  buyer_phone: string
  quantity: number
  attendees: Attendee[]
  total_amount: number
  payment_status: PaymentStatus
  payment_method: PaymentMethod
  asaas_payment_id?: string | null
  pix_qr_code?: string | null
  pix_copy_paste?: string | null
  card_checkout_url?: string | null
  created_at: string
}

export interface Ticket {
  id: string
  registration_id: string
  event_id: string
  attendee_name: string
  qr_token: string
  checked_in: boolean
  checked_in_at: string | null
}

export interface WaitlistEntry {
  id: string
  event_id: string
  batch_id: string | null
  name: string
  email: string
  phone: string
  quantity_wanted: number
  status: WaitlistStatus
  created_at: string
}

export interface AdminInfo {
  id: string
  email: string
  name: string
}
