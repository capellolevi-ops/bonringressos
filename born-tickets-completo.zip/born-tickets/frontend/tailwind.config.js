/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#09090b',
        surface: '#131316',
        surface2: '#1a1a1e',
        border: '#2a2a2e',
        ink: '#f6f3ec',
        muted: '#a8a396',
        gold: {
          light: '#ecd08c',
          DEFAULT: '#cda45e',
          dark: '#a67c3d',
        },
      },
      fontFamily: {
        display: ['"Playfair Display"', 'Georgia', 'serif'],
        body: ['Poppins', '-apple-system', 'sans-serif'],
      },
      borderRadius: {
        card: '18px',
      },
    },
  },
  plugins: [],
}
